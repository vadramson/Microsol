


# History

### 1.2.11
* fix the position bug with svg.


### 1.2.10
* fix the hidden bug in show method when trigger is set to 'manual'.


### 1.2.9
* fix the position in container bug

### 1.2.8
* fix and optimize the scroll placement bug
* add rtl direction support
* fix arrow hide bug when placement is set to auto or auto-buttom
* fix the LESS variable collision


### 1.2.7
* fix the scroll placement bug

### 1.2.6
* fix the hidden bug on mobile device when trigger is set to 'hover'
* add the loging.gif to the CDN

### 1.2.4
* add async request method option:async.type,default value is 'GET'.
* optimize the close button, make it more customizable.


### 1.2.3
* fix the bug which cause the popover hide by click when multi popovers in same page.
* optimize event handling for performance

### 1.2.2
*
* optimize code and clean debug info

### 1.2.1
* now option url can be set with jQuery selector (eg: '#myContent') when type equals 'html'.
* fix the bug which cause the popover content lost event handler.


### 1.2.0
* make the  animation avaiable for hidding.
* add new trigger:'sticky'.
* remove the option:constrains, move the value 'horizontal/vertical' to placement.
* fix the bug which caused the  popover can't be closed on mobile device.
* new way to init popover content, set the content by next element html which has class 'webui-popover'.
* optimese the calulate position  algorithm.
* update the demo page adapt for mobile device.
