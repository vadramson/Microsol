
2015-12

* Optimize the display on mobile device
* Add fit width/height to some container
* Nested popover support
* unique option for performer optimize when huge number of the popovers in same page.